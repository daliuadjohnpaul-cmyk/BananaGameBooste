package com.banana.gamebooster;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final int bg=Color.rgb(7,17,15), panel=Color.rgb(17,32,28), green=Color.rgb(102,227,165),
        white=Color.rgb(239,249,243), muted=Color.rgb(164,187,174);
    LinearLayout root, games;
    TextView count;

    public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);ui();loadGames();}
    GradientDrawable shape(int c,int r,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(r);if(stroke!=0)d.setStroke(1,stroke);return d;}
    TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout.LayoutParams lp(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    void gap(LinearLayout l,int h){l.addView(new View(this),lp(1,h));}
    TextView action(String s,Runnable r){TextView t=txt(s,12,bg,true);t.setGravity(Gravity.CENTER);t.setPadding(14,12,14,12);t.setBackground(shape(green,24,0));t.setOnClickListener(v->r.run());return t;}

    void ui(){
        ScrollView sc=new ScrollView(this);root=col();root.setPadding(20,18,20,24);root.setBackgroundColor(bg);sc.addView(root);setContentView(sc);
        root.addView(txt("🍌  BANANA LABS",12,green,true),lp(-1,28));gap(root,8);
        root.addView(txt("GAME BOOSTER",30,white,true),lp(-1,40));
        root.addView(txt("REALME NOTE 50  •  ANDROID 15",11,muted,true),lp(-1,25));gap(root,18);
        LinearLayout hero=col();hero.setPadding(18,18,18,18);hero.setBackground(shape(panel,22,Color.rgb(37,71,55)));root.addView(hero,lp(-1,-2));
        hero.addView(txt("GAMING CONTROL CENTER",11,green,true));gap(hero,8);
        hero.addView(txt("Less clutter. Faster access.",21,white,true));gap(hero,5);
        TextView desc=txt("Launch games and open Android controls. No fake FPS claims or hidden background-app killing.",13,muted,false);desc.setGravity(Gravity.TOP);hero.addView(desc,lp(-1,-2));gap(hero,14);
        hero.addView(action("OPEN DO NOT DISTURB SETTINGS  ↗",()->open(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)),lp(-1,48));gap(root,18);
        LinearLayout heading=new LinearLayout(this);heading.setGravity(Gravity.CENTER_VERTICAL);root.addView(heading,lp(-1,32));
        heading.addView(txt("YOUR INSTALLED GAMES",13,white,true),new LinearLayout.LayoutParams(0,-1,1));
        count=txt("SCANNING",10,green,true);heading.addView(count,lp(-2,-1));gap(root,8);
        games=col();root.addView(games,lp(-1,-2));gap(root,18);
        root.addView(txt("QUICK TOOLS",13,white,true),lp(-1,28));gap(root,8);
        tool("Battery settings","Review power use",Settings.ACTION_BATTERY_SAVER_SETTINGS);
        tool("Display settings","Adjust refresh rate or brightness",Settings.ACTION_DISPLAY_SETTINGS);
        tool("App info","Review this app's permissions and storage",null);gap(root,18);
        TextView foot=txt("NO ROOT • NO HIDDEN TWEAKS\nPerformance depends on game, temperature and device limits.",10,muted,false);foot.setGravity(Gravity.CENTER);root.addView(foot,lp(-1,50));
    }
    void tool(String title,String sub,String action){
        LinearLayout c=new LinearLayout(this);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(14,12,12,12);c.setBackground(shape(panel,15,Color.rgb(35,56,47)));
        c.addView(txt(title+"\n"+sub,13,white,true),new LinearLayout.LayoutParams(0,-2,1));c.addView(txt("↗",20,green,true),lp(26,42));
        c.setOnClickListener(v->{if(action==null){Intent i=new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()));startActivity(i);}else open(action);});
        LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=8;root.addView(c,p);
    }
    void open(String action){try{startActivity(new Intent(action));}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_SETTINGS));}catch(Exception ignored){Toast.makeText(this,"Open Settings manually",0).show();}}}
    void loadGames(){
        if(games==null)return;games.removeAllViews();Intent q=new Intent(Intent.ACTION_MAIN,null);q.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm=getPackageManager();List<ResolveInfo> apps=pm.queryIntentActivities(q,0);
        Collections.sort(apps,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        int n=0;
        for(ResolveInfo ri:apps){String pkg=ri.activityInfo.packageName;if(pkg.equals(getPackageName()))continue;
            String name=String.valueOf(ri.loadLabel(pm)),s=(name+" "+pkg).toLowerCase(Locale.ROOT);
            String[] keys={"game","mobile legends","mlbb","roblox","minecraft","free fire","pubg","call of duty","codm","genshin","wild rift","geometry dash","asphalt","subway surfers","stumble guys","clash"};
            boolean match=false;for(String k:keys)if(s.contains(k)){match=true;break;}if(!match)continue;
            LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(12,9,10,9);row.setBackground(shape(panel,15,Color.rgb(35,56,47)));
            ImageView icon=new ImageView(this);icon.setImageDrawable(ri.loadIcon(pm));row.addView(icon,lp(42,42));
            LinearLayout copy=col();copy.setPadding(11,0,4,0);copy.addView(txt(name,14,white,true),lp(-1,24));copy.addView(txt("Installed app",11,muted,false),lp(-1,20));
            row.addView(copy,new LinearLayout.LayoutParams(0,-2,1));TextView play=txt("PLAY ▶",11,bg,true);play.setGravity(Gravity.CENTER);play.setPadding(10,10,10,10);play.setBackground(shape(green,18,0));row.addView(play,lp(-2,-2));
            row.setOnClickListener(v->{Intent launch=pm.getLaunchIntentForPackage(pkg);if(launch!=null)try{startActivity(launch);}catch(Exception e){Toast.makeText(this,"Could not launch app",0).show();}});
            LinearLayout.LayoutParams p=lp(-1,-2);p.bottomMargin=8;games.addView(row,p);n++;
        }
        count.setText(n+" FOUND");
        if(n==0){TextView empty=txt("No matching games detected. Game detection uses app-name keywords and may miss some titles.",13,muted,false);empty.setPadding(14,18,14,18);empty.setBackground(shape(panel,15,0));games.addView(empty,lp(-1,-2));}
    }
    protected void onResume(){super.onResume();if(games!=null)loadGames();}
}
