# Banana Game Booster — Android project starter

A simple native Android launcher/control panel intended for a Realme Note 50 on Android 15.

Features:
- Dark gaming dashboard
- Keyword-based discovery of installed launchable apps
- One-tap game launch
- Shortcuts to Android battery, display, and Do Not Disturb settings
- No root, no secret commands, no fake FPS claims

## Build an APK using only a phone (GitHub Actions)
1. Extract this ZIP on your phone.
2. Create a new public or private repository on GitHub named `BananaGameBooster`.
3. Upload the *contents* of the extracted `BananaGameBooster` folder to the repository root. Make sure the `.github/workflows/build-apk.yml` file is included. If the GitHub mobile upload page hides dot-folders, use GitHub's web interface in desktop mode or create the workflow file directly in the repository.
4. Open the repository's **Actions** tab and select **Build Banana Game Booster APK**.
5. Tap **Run workflow** if it has not run automatically after upload.
6. When the run finishes successfully, open that run and download the artifact named `Banana-Game-Booster-debug-APK`.
7. Extract the downloaded artifact ZIP. Tap `app-debug.apk` to install it. If Android asks, allow your browser or file manager to install unknown apps for this installation only, then return and install.
8. Find **Banana Game Booster** in the app drawer and choose **Add to Home screen** if needed.

The APK is an unsigned-for-store debug build, suitable for personal testing. Android may display a warning because it was installed outside the Play Store. Only install builds you created from this source.

## Limitations
This is not Realme's proprietary Game Space and cannot replace or install Realme system components. It does not change CPU/GPU clocks, thermal limits, network routing, or hidden system settings. Android may restrict some settings depending on firmware. Detection is keyword-based, so some games may be missed.
